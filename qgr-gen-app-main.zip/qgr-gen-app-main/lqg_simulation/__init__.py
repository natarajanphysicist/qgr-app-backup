# lqg_simulation/__init__.py
# This file makes 'lqg_simulation' a top-level Python package.

# You can make key classes/functions available at the top level, e.g.:
# from .core import SpinNetwork
# from .mathematics import wigner_symbols # Example, once it exists
