# lqg_simulation/mathematics/__init__.py
# This file makes the 'mathematics' directory a Python package.

# You can optionally import modules here to make them available
# at the package level, e.g.:
# from . import wigner_symbols
