# lqg_simulation/plotting/__init__.py
# This file makes the 'plotting' directory a Python package.
