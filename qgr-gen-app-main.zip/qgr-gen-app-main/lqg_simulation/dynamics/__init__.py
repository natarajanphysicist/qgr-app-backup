# lqg_simulation/dynamics/__init__.py
# This file makes the 'dynamics' directory a Python package.

from .amplitudes import calculate_placeholder_vertex_amplitude
