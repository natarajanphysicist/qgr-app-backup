# lqg_simulation/examples/__init__.py
# This file makes the 'examples' directory a Python package.
